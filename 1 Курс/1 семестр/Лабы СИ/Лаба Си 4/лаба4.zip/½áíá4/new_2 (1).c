#include <stdio.h>

void move_right(int *mas1, int *mas2, int N, int K) {	
	for (int i = 0; i < N; i++) {
		mas2[K] = mas1[i];
		K++;
		if (K == N) {
			K = 0;
		}
	}
}

void move_left (int *mas1, int *mas2, int N, int K) {
	for (int i = N - 1; i >= 0; i--) {
		mas2[N - 1 - K] = mas1[i];
		K++;
		if ((N - 1 - K) < 0) {
			K = 0;
		}
	}
}

int main() { 
	int mas1[100000] = {0}; 
	int mas2[100000] = {0}; 
	int N, K, flag; 
	scanf("%d", &N);  

	for (int i = 0; i < N; i++){ 
		scanf("%d", &mas1[i]); 
	} 

	scanf("%d", &K); 
	
	flag = (K > 0) ? 1 : 0; 
	K = (flag) ? K : -K; 

	K = K % N; 


	if (flag){ 
		move_right(mas1, mas2, N, K); 
	} 
	else { 
		move_left(mas1, mas2, N, K); 
	} 

	for(int i = 0; i < N; i++){ 
		printf("%d ", mas2[i]); 
	} 

	return 0; 
}