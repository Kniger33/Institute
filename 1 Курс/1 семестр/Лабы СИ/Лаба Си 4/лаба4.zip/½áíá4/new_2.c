#include <stdio.h> 
#include <stdlib.h> 
#define STK_SIZE 1010 

int push(int *stek, int *top_stek, int data) 
{ 
	if (*top_stek >= STK_SIZE) {
		return 0; 
	}
	else { 
		stek[*top_stek] = data; 
		*top_stek += 1; 
		return 1; 
	} 
} 

int pop(int *stek, int *top_stek, int *data) { 
	if (*top_stek != 0) { 
		*top_stek -= 1; 
		*data = stek[*top_stek]; 
		return 1; 
	} 
	else return 0; 
} 

int main() 
{ 
	int stek_color[STK_SIZE] = {0}; 
	int stek_number[STK_SIZE] = {0}; 
	int top_stek_color = 0, top_stek_number = 0; 
	int num_balloons = 0, input_color = 0, count = 1; 
	int i, current_color = 0, flag = 0, sum_dest = 0; 

	scanf("%d%d", &num_balloons, &current_color); 

	for (i = 1; i < num_balloons; i++) { 
		scanf("%d", &input_color); 
		if (current_color == input_color) { 
	count++; 
	continue; 
} 

	if (count > 2) { 
		flag = 1; 
		sum_dest += count; 
	} 
	else 
	if (flag) { 
		count = 0; 
		break; 
	} 

	if (flag == 0) { 
		push(stek_color, &top_stek_color, current_color); 
		push(stek_number, &top_stek_number, count); 
		current_color = input_color; 
		count = 1; 
	} 
	else { 
		pop(stek_color, &top_stek_color, &current_color); 
		pop(stek_number, &top_stek_number, &count); 
		if (current_color == input_color) {
			count++; 
		}
		else 
		break; 
		} 
	} 
	if (count > 2) { 
	sum_dest += count;
	}
	printf("%d", sum_dest); 
	return 0; 
}